class Content < ActiveRecord::Base
end
