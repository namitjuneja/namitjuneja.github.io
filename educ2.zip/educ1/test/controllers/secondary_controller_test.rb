require 'test_helper'

class SecondaryControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
